Travail en binôme pour Le Mini-projet du module “Programmation 2” en langage C
Fait par : Ghedamsi Youcef, Beldjoudi Wissameddine ( Groupe 03 L1 informatique )

Description du code :
Le code est une implémentation du jeu classique "Snake" en langage C. Il utilise des fonctions pour allouer une grille, créer un serpent, 
gérer les mouvements du serpent, placer des fruits aléatoires sur la grille, et redessiner la grille à l'écran. 

Fonctionnement :
Le jeu démarre avec un serpent et une grille vide. Le joueur peut contrôler le serpent à l'aide des touches directionnelles pour le faire 
se déplacer dans la grille. L'objectif est de faire manger au serpent des fruits placés aléatoirement sur la grille, ce qui fait grandir 
le serpent et augmente le score. Le jeu se termine lorsque le serpent entre en collision avec lui-même ou avec les bords de la grille.
Le jeu se lance avec la commande ./exec sur le terminal suivi des dimensions de la grille, de la vitesse de réactualisation en dixiement 
de secondes (de preferences 2 ou 3) puis du nombre de joueurs ( 1 ou 2 ) 

Utilisation de GitHub : Nous avons utilisé GitHub pour partager les tâches et coordonner notre travail. Chacun d'entre nous a travaillé 
sur différentes parties du code, puis nous avons fusionné nos contributions à chaque fin d'exercice, et on a traviller ensemble.